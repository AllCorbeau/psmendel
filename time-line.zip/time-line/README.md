# Time line

A Pen created on CodePen.io. Original URL: [https://codepen.io/MidoElSayaad/pen/QGRjqp](https://codepen.io/MidoElSayaad/pen/QGRjqp).

Time line using Html & Css